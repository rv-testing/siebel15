<script language="javascript" type="text/javascript">
<!--//
var resultOutput = false;
function loadFocus(i) {
	if (resultOutput == false) {
		document.forms[0].elements[i].focus();
	}
}

function loadFocus(form, name) {
	if (resultOutput == false && null != form) {
		form.elements[name].focus();
	}
}
//-->
</script>