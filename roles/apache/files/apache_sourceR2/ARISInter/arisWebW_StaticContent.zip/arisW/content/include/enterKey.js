<script language="javascript" type="text/javascript">
<!--
function enterSubmit(nameButton)
{
	var key;

	if (navigator.appName=='Microsoft Internet Explorer') key = window.event.keyCode;

	else if (navigator.appName=='Netscape' || navigator.vendorSub!=null) key = z.which;

	if (key == "13")
	{
		document.forms[0].elements[nameButton].focus();
		document.forms[0].elements[nameButton].click();
	}
}
//-->
</script>
