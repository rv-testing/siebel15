<script language="javascript" type="text/javascript">
function scrollAnchor(){
	document.location.href = "#top";
}
</script>