<script language="javascript" type="text/javascript">
<!--//
	var enterPressedOnce = false;
	var cancelButton = false;
	function checkDuplicate() {
	if (document.forms[0].cancel!=null) {
		cancelButton = true;
	}
		if (!enterPressedOnce) {
        	enterPressedOnce = true;
        	document.forms[0].back.disabled = true;
			if (cancelButton) {
				document.forms[0].cancel.disabled = true;
			} else {
				document.forms[0].cancelFirst.disabled = true;
			}
			if (document.forms[0].clear!=null)
				document.forms[0].clear.disabled = true;
				
			return true;			
        } else {
			document.forms[0].enter.disabled = true;
			document.forms[0].back.disabled = true;
			if (cancelButton) {
				document.forms[0].cancel.disabled = true;
			} else {
				document.forms[0].cancelFirst.disabled = true;
			}
			if (document.forms[0].clear!=null)
				document.forms[0].clear.disabled = true;
				
			return false;	
		}
	}
//-->
</script>