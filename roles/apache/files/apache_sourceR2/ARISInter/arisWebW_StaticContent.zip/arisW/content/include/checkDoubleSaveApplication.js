<script language="javascript" type="text/javascript">
<!--//
	var enterPressedOnce = false;
	
	function checkDoubleSaveApplication() {
	
		if (!enterPressedOnce) {
			
        	enterPressedOnce = true;
        	return true;
        	
        } else {
			document.forms[0].save_complete_AR.disabled = true;
							
			return false;	
		}
	}
//-->
</script>





