<script language="javascript" type="text/javascript">
<!--//

// function to check muliple clicks while request is being processed
click_counter = 0;
function submitMonitor(msg) {
 click_counter++;
 if(click_counter >1) {
   alert(msg);
   return false;
 }
 
 return true;
}

//-->
</SCRIPT>
