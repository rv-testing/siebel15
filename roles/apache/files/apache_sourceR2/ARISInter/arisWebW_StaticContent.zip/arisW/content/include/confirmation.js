<script language="javascript" type="text/javascript">
<!--//
function confirmation_external() {
	var cancel = confirm("Selecting Cancel does not save any changes you have made.\n\n Are you sure you want to cancel this action?");
	if (cancel == true) {	
		window.location.href = "<html:rewrite page='/cancel.do'/>";
	}
}
function confirmation_internal() {
	confirmation_external();
}
function confirmation_specific() {
	var cancel = confirm("Selecting Cancel does not save any changes you have made.\n\n Are you sure you want to cancel this action?");
	if (cancel == true) {	
		document.forms[0].back.click();
	}
}
//-->
</SCRIPT>
