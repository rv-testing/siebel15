<script language="JavaScript" type="text/javascript">
function clearSelections(data)
{
	for (i=0; i < document.auditResultsForm.elements.length;i++)
	{
		if (document.auditResultsForm.elements[i].name == 'selectedAuditResult' && document.auditResultsForm.elements[i] != data)
			document.auditResultsForm.elements[i].checked = false;
	}
}

function clearFullCompliance()
{
	for (i=0; i < document.auditResultsForm.elements.length;i++)
	{
		if (document.auditResultsForm.elements[i].name == 'selectedAuditResult' && document.auditResultsForm.elements[i].value == <%= AuditResultDetailType.Constants.FULL_COMPLIANCE.getId() %>)
			document.auditResultsForm.elements[i].checked = false;
	}
}
</script>