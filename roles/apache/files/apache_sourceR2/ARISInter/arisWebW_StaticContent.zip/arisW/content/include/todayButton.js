<script language="javascript" type="text/javascript">
<!--//
function loadDate(event) {
	var today = new Date();
	var year = today.getFullYear();
	var month = today.getMonth() + 1;
	var day = today.getDate();
	year = year.toString();
	month = month.toString();
	day = day.toString();
	if (month.length == 1) {
		month = "0"+month;
	}
	if (day.length == 1) {
		day = "0"+day;
	}
	$(this).parent().find('input:text[id$="year"]').val(year);
	$(this).parent().find('input:text[id$="month"]').val(month);
	$(this).parent().find('input:text[id$="day"]').val(day);
}
//-->
</script>
